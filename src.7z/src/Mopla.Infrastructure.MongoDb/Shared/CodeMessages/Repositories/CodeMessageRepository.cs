﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Mopla.Domain.Shared.CodeMessages.Models;
using Mopla.Domain.Shared.CodeMessages.Repositories;
using Mopla.Infrastructure.MongoDb.Common;
using Mopla.Infrastructure.MongoDb.Shared.CodeMessages.Documents;
using Mopla.Infrastructure.MongoDb.Shared.CodeMessages.Mappers;

namespace Mopla.Infrastructure.MongoDb.Shared.CodeMessages.Repositories
{
    public class CodeMessageRepository : ICodeMessageRepository
    {
        private readonly IDataBaseFacade databaseFacade;
        private readonly string collectionName;

        public CodeMessageRepository(IDataBaseFacade databaseFacade)
                : this(databaseFacade, CollectionsNames.CodeMessagesCollectionName)
        {
        }

        public CodeMessageRepository(IDataBaseFacade databaseFacade, string collectionName)
        {
            if (string.IsNullOrWhiteSpace(collectionName))
                throw new ArgumentNullException(nameof(collectionName));

            this.collectionName = collectionName;
            this.databaseFacade = databaseFacade ?? throw new ArgumentNullException(nameof(databaseFacade));
            CreateCollectionAndIndexes();
        }

        private void CreateCollectionAndIndexes()
        {
            var collectionExists = databaseFacade.CollectionExistsAsync(collectionName).Result;
            databaseFacade.CreateCollectionIfNotExistsAsync<CodeMessageDocument>(collectionName);
            databaseFacade.CreateIndexIfNotExistsAsync<CodeMessageDocument>(collectionName, e => e.Code, "code");
            Seed();
        }

        public CodeMessage Obter(string code)
        {
            var document = databaseFacade.FindOne<CodeMessageDocument>(collectionName, expr => expr.Code == code);
            return document.Mapper();
        }

        public async Task<CodeMessage> ObterAsync(string code)
        {
            var document = await databaseFacade.FindOneAsync<CodeMessageDocument>(collectionName, expr => expr.Code == code);
            return document.Mapper();
        }

        private void Seed()
        {
            var codeMessages = new List<CodeMessageDocument>
            {
                new CodeMessageDocument { Code = "MOV-PLA-001", Message = "O número da página deve ser maior que zero." },
                new CodeMessageDocument { Code = "MOV-PLA-002", Message = "Número de registros por página deve ser maior que zero." },
                new CodeMessageDocument { Code = "MOV-PLA-003", Message = "Pelo menos um tipo de ambiente deve ser informado." },
                new CodeMessageDocument { Code = "MOV-PLA-004", Message = "Atributo obrigatório.", FormattedMessage = "O atributo [{0}] é obrigatório." },
                new CodeMessageDocument { Code = "MOV-PLA-005", Message = "O atributo deve ser maior que zero.", FormattedMessage = "O atributo [{0}] deve ser maior que zero." },
             
                //...
                new CodeMessageDocument { Code = "MOV-PLA-400", Message = "Bad Request" },
                new CodeMessageDocument { Code = "MOV-PLA-500", Message = "Internal Server Error" },
            };

            databaseFacade.BulkWriteAsync(collectionName, codeMessages, null);
        }
    }
}

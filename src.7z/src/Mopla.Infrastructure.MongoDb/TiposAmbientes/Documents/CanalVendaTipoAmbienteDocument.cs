﻿using MongoDB.Bson.Serialization.Attributes;

namespace Mopla.Infrastructure.MongoDb.TiposAmbientes.Documents
{
    internal class CanalVendaTipoAmbienteDocument
    {
        [BsonElement]
        internal string IdCanal { get; set; }
        [BsonElement]
        internal int IdUnidadeNegocio { get; set; }
        [BsonElement]
        internal short Ordem { get; set; }
    }
}
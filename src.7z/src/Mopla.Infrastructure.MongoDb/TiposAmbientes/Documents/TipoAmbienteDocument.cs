﻿using MongoDB.Bson.Serialization.Attributes;
using System.Collections.Generic;

namespace Mopla.Infrastructure.MongoDb.TiposAmbientes.Documents
{
    internal class TipoAmbienteDocument
    {
        [BsonId]
        [BsonIgnoreIfDefault]
        internal string Id { get; set; }
        [BsonElement]
        internal string Nome { get; set; }
        [BsonElement]
        internal bool Ativo { get; set; }
        [BsonElement]
        internal IList<CanalVendaTipoAmbienteDocument> Canais { get; set; } = new List<CanalVendaTipoAmbienteDocument>();
    }
}

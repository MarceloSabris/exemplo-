﻿using Mopla.Domain.TiposAmbientes.Models;
using Mopla.Infrastructure.MongoDb.TiposAmbientes.Documents;
using System;
using System.Collections.Generic;

namespace Mopla.Infrastructure.MongoDb.TiposAmbientes.Mappers
{
    internal static class TipoAmbienteMapper
    {
        internal static TipoAmbiente Map(this TipoAmbienteDocument document)
        {
            return TipoAmbiente.Criar(Guid.Parse(document.Id), document.Nome, document.Ativo, document.Canais.Map());
        }

        internal static TipoAmbienteDocument Map(this TipoAmbiente entity)
        {
            return new TipoAmbienteDocument
            {
                Id = entity.Id.ToString(),
                Nome = entity.Nome,
                Canais = entity.Canais.Map(),
                Ativo = entity.Ativo
            };
        }

        internal static IList<TipoAmbiente> Map(this IList<TipoAmbienteDocument> documents)
        {
            var entities = new List<TipoAmbiente>();
            if (documents != null)
            {
                foreach (var document in documents)
                {
                    var entity = TipoAmbiente.Criar(Guid.Parse(document.Id), document.Nome, document.Ativo, document.Canais.Map());
                    entities.Add(entity);
                }
            }
            return entities;
        }

        internal static IList<TipoAmbienteDocument> Map(this IList<TipoAmbiente> entities)
        {
            var documents = new List<TipoAmbienteDocument>();
            if (entities != null)
            {
                foreach (var entity in entities)
                    documents.Add(entity.Map());
            }
            return documents;
        }

        internal static CanalVendaTipoAmbiente Map(this CanalVendaTipoAmbienteDocument document)
        {
            return CanalVendaTipoAmbiente.Criar(document.IdCanal, document.IdUnidadeNegocio, document.Ordem);
        }

        internal static IList<CanalVendaTipoAmbiente> Map(this IList<CanalVendaTipoAmbienteDocument> documents)
        {
            var entities = new List<CanalVendaTipoAmbiente>();
            if (documents != null)
            {
                foreach (var document in documents)
                    entities.Add(document.Map());
            }
            return entities;
        }

        internal static CanalVendaTipoAmbienteDocument Map(this CanalVendaTipoAmbiente entity)
        {
            return new CanalVendaTipoAmbienteDocument
            {
                IdCanal = entity.IdCanal,
                IdUnidadeNegocio = entity.IdUnidadeNegocio,
                Ordem = entity.Ordem
            };
        }

        internal static IList<CanalVendaTipoAmbienteDocument> Map(this IList<CanalVendaTipoAmbiente> entities)
        {
            var documents = new List<CanalVendaTipoAmbienteDocument>();
            if (entities != null)
            {
                foreach (var entity in entities)
                    documents.Add(entity.Map());
            }
            return documents;
        }
    }
}

﻿using Mopla.Domain.TiposAmbientes.Models;
using Mopla.Domain.TiposAmbientes.Repositories;
using Mopla.Infrastructure.MongoDb.Common;
using Mopla.Infrastructure.MongoDb.TiposAmbientes.Documents;
using Mopla.Infrastructure.MongoDb.TiposAmbientes.Mappers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Mopla.Infrastructure.MongoDb.TiposAmbientes.Repositories
{
    public class TipoAmbienteMongoRepository : ITipoAmbienteRepository
    {
        private readonly IDataBaseFacade databaseFacade;
        private readonly string collectionName;
        private static object syncRoot = new object();

        public TipoAmbienteMongoRepository(IDataBaseFacade databaseFacade)
                : this(databaseFacade, CollectionsNames.TiposAmbientesCollectionName)
        {
        }

        public TipoAmbienteMongoRepository(IDataBaseFacade databaseFacade, string collectionName)
        {
            this.collectionName = collectionName;
            this.databaseFacade = databaseFacade;
            CreateCollectionAndIndexes();
        }

        private void CreateCollectionAndIndexes()
        {
            var collectionExists = databaseFacade.CollectionExistsAsync(collectionName).Result;
            databaseFacade.CreateCollectionIfNotExistsAsync<TipoAmbienteDocument>(collectionName);
            databaseFacade.CreateIndexIfNotExistsAsync<TipoAmbienteDocument>(collectionName, t => t.Id, "id");
        }

        public async Task<IList<TipoAmbiente>> ListarAsync(FiltroTipoAmbiente filtro)
        {
            Expression<Func<TipoAmbienteDocument, bool>> filter = expr =>
                (expr.Id == filtro.Id.ToString() || filtro.Id == Guid.Empty) &&
                (expr.Ativo == filtro.Ativo || filtro.Ativo == null) &&
                (expr.Canais.Any(c => (c.IdCanal == filtro.IdCanalVenda || string.IsNullOrWhiteSpace(filtro.IdCanalVenda)) ||
                                      (c.IdUnidadeNegocio == filtro.IdUnidadeNegocio || filtro.IdUnidadeNegocio == null))
                );

            var documents = await databaseFacade.FindAsync(collectionName, filter);
            return documents.Map();
        }

        public async Task<TipoAmbiente> Obter(Guid id)
        {
            Expression<Func<TipoAmbienteDocument, bool>> filter = expr => expr.Id == id.ToString();
            var document = await databaseFacade.FindOneAsync(collectionName, filter);
            return document.Map();
        }

        public async Task SalvarAsync(TipoAmbiente tipoAmbiente)
        {
            var document = tipoAmbiente.Map();
            await databaseFacade.SaveAsync(collectionName, document, current => Equals(current.Id, tipoAmbiente.Id.ToString()));
        }

        public async Task SalvarAsync(IList<TipoAmbiente> tiposAmbiente)
        {
            Parallel.ForEach(tiposAmbiente, async (tipoAmbiente) => await SalvarAsync(tipoAmbiente));
        }
    }
}

﻿namespace Mopla.Infrastructure.MongoDb.Common
{
    public sealed class CollectionsNames
    {
        public const string CodeMessagesCollectionName = "CodeMessages";
        public const string TiposAmbientesCollectionName = "TiposAmbientes";
        public const string AmbientesCollectionName = "Ambientes";        
    }
}

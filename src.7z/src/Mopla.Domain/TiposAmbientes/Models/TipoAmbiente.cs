﻿using System;
using System.Collections.Generic;

namespace Mopla.Domain.TiposAmbientes.Models
{
    /// <summary>
    /// Representa um tipo de ambiente.
    /// </summary>
    public class TipoAmbiente
    {
        private TipoAmbiente(Guid id, string nome, bool ativo, IList<CanalVendaTipoAmbiente> canais)
        {
            if (string.IsNullOrWhiteSpace(nome))
                throw new ArgumentNullException(nome);

            Id = id;
            Nome = nome;
            Ativo = ativo;
            Canais = canais;
        }
        public Guid Id { get; private set; }
        public string Nome { get; private set; }
        public bool Ativo { get; private set; }
        public IList<CanalVendaTipoAmbiente> Canais { get; private set; } = new List<CanalVendaTipoAmbiente>();
        public static TipoAmbiente Criar(string id, string nome, bool ativo, IList<CanalVendaTipoAmbiente> canais)
        {
            Guid.TryParse(id, out Guid guid);
            if (guid == Guid.Empty)
                guid = Guid.NewGuid();

            return Criar(guid, nome, ativo, canais);
        }
        public static TipoAmbiente Criar(Guid id, string nome, bool ativo, IList<CanalVendaTipoAmbiente> canais)
        {
            return new TipoAmbiente(id, nome, ativo, canais);
        }
    }
}
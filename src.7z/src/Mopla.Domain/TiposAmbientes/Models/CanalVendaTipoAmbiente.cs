﻿using Mopla.Domain.Shared.Canais.Models;
using System;

namespace Mopla.Domain.TiposAmbientes.Models
{
    /// <summary>
    /// Representa um canal de venda para um tipo de ambiente.
    /// </summary>
    public sealed class CanalVendaTipoAmbiente : CanalVenda
    {
        private CanalVendaTipoAmbiente(string idCanal, int idUnidadeNegocio, short ordem) : base(idCanal, idUnidadeNegocio)
        {
            if (ordem < 0)
                throw new ArgumentOutOfRangeException(nameof(ordem));

            Ordem = ordem;
        }

        public short Ordem { get; private set; }

        /// <summary>
        /// Responsible for creating the sales channel. (Factory Method)
        /// </summary>
        /// <param name="idCanal">O id do canal de venda.</param>
        /// <param name="idUnidadeNegocio">Identificador da unidade de negócio.</param>
        /// <param name="ordem">Ordem de exibição.</param>
        /// <returns></returns>
        public static CanalVendaTipoAmbiente Criar(string idCanal, int idUnidadeNegocio, short ordem)
        {
            return new CanalVendaTipoAmbiente(idCanal, idUnidadeNegocio, ordem);
        }
    }
}
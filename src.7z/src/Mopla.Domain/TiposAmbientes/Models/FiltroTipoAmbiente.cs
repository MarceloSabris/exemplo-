﻿using System;

namespace Mopla.Domain.TiposAmbientes.Models
{
    /// <summary>
    /// Representa um filtro para listar os tipos de ambiente.
    /// </summary>
    public class FiltroTipoAmbiente
    {
        public Guid Id { get; set; } = Guid.Empty;
        public string IdCanalVenda { get; set; }
        public int? IdUnidadeNegocio { get; set; }
        public bool? Ativo { get; set; }
    }
}

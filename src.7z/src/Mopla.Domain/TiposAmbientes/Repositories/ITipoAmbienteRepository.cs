﻿using Mopla.Domain.TiposAmbientes.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Mopla.Domain.TiposAmbientes.Repositories
{
    public interface ITipoAmbienteRepository
    {
        Task SalvarAsync(TipoAmbiente tipoAmbiente);
        Task SalvarAsync(IList<TipoAmbiente> tiposAmbiente);
        Task<IList<TipoAmbiente>> ListarAsync(FiltroTipoAmbiente filtro);
        Task<TipoAmbiente> Obter(Guid id);
    }
}
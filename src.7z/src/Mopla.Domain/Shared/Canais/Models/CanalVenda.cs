﻿using System;

namespace Mopla.Domain.Shared.Canais.Models
{
    public class CanalVenda
    {
        protected CanalVenda(string idCanal, int idUnidadeNegocio)
        {
            if (string.IsNullOrWhiteSpace(idCanal))
                throw new ArgumentNullException(nameof(idCanal));

            if (idUnidadeNegocio == default(int))
                throw new ArgumentNullException(nameof(idUnidadeNegocio));

            IdCanal = idCanal;
            IdUnidadeNegocio = idUnidadeNegocio;
        }

        public string IdCanal { get; private set; }
        public int IdUnidadeNegocio { get; private set; }

        /// <summary>
        /// Responsible for creating the sales channel. (Factory Method)
        /// </summary>
        /// <param name="idCanal">O id do canal de venda.</param>
        /// <param name="idUnidadeNegocio">Identificador da unidade de negócio.</param>
        /// <returns></returns>
        public static CanalVenda Criar(string idCanal, int idUnidadeNegocio)
        {
            return new CanalVenda(idCanal, idUnidadeNegocio);
        }
    }
}
﻿using Mopla.Domain.Shared.CodeMessages.Models;
using System.Threading.Tasks;

namespace Mopla.Domain.Shared.CodeMessages.Repositories
{
    public interface ICodeMessageRepository
    {
        CodeMessage Obter(string code);
        Task<CodeMessage> ObterAsync(string code);
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Mopla.Domain.Shared.CodeMessages.Models
{
    public class CodeMessage
    {
        private string _message;

        public CodeMessage()
            : this(string.Empty)
        {
        }

        public CodeMessage(string code)
            : this(code, string.Empty)
        {
        }

        public CodeMessage(string code, string message)
            : this(code, message, string.Empty)
        {
        }

        public CodeMessage(string code, string message, string formattedMessage)
        {
            Code = code;
            Message = message;
            FormattedMessage = formattedMessage;
        }

        public string Code { get; set; }

        public string Message
        {
            get
            {
                if (HasFormattedMessage && Values.Any())
                    return GetFormattedMessage(Values.ToArray());

                return _message;
            }
            set { _message = value; }
        }

        public string FormattedMessage { get; set; }

        public bool HasFormattedMessage { get { return !string.IsNullOrWhiteSpace(FormattedMessage); } }

        public string GetFormattedMessage(params string[] values)
        {
            return string.Format(FormattedMessage, values);
        }

        public IList<string> Values { get; private set; } = new List<string>();

        public void AddValue(string value)
        {
            if (HasFormattedMessage)
                Values.Add(value);
        }

        public override string ToString()
        {
            if (string.IsNullOrWhiteSpace(Code) && !string.IsNullOrWhiteSpace(Message))
                return $"{Code}-{Message}";

            return base.ToString();
        }

        public const string BadRequest = "MOV-PLA-400";
        public const string InternalServerError = "MOV-PLA-500";

        public const string NumeroPaginaDeveSerMaiorZero = "MOV-PLA-001";
        public const string NumeroRegistrosDeveSerMaiorZero = "MOV-PLA-002";
        public const string PeloMenosUmTipoAmbienteDeveSerInformado = "MOV-PLA-003";
        public const string AtributoObrigatorio = "MOV-PLA-004";
        public const string AtributoDeveSerMaiorQueZero = "MOV-PLA-005";
    }
}

﻿using Enterprise.Infrastructure.Services.Messages;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using TipoMensagem = Enterprise.Infrastructure.Common.Enumerations.TipoMensagem;

namespace Mopla.WebApi
{
    public static class ControllerExtensions
    {

        public static ActionResult GetHttpResponse(this Controller controller, BaseResponse response)
        {
            if (response == null)
                return controller.BadRequest(response);

            if (!response.Valido)
            {
                if (!response.Mensagens.Any())
                    return controller.BadRequest(response);

                if (response.Mensagens.Any(m => m.Tipo == TipoMensagem.ErroValidacao || m.Tipo == TipoMensagem.Validacao))
                    return controller.BadRequest(response);

                if (response.Mensagens.Any(m => m.Tipo == TipoMensagem.ErroNegocio || m.Tipo == TipoMensagem.Negocio))
                    return controller.Conflict(response);

                if (response.Mensagens.Any(m => m.Tipo == TipoMensagem.ErroAplicacao || m.Tipo == TipoMensagem.Aplicacao))
                    return controller.Error(response);
            }
            return controller.Ok(response);
        }

        public static ActionResult Conflict(this Controller controller, BaseResponse response)
        {
            return new ObjectResult(response)
            {
                StatusCode = StatusCodes.Status409Conflict
            };
        }

        public static ActionResult Error(this Controller controller, BaseResponse response)
        {
            return new ObjectResult(response)
            {
                StatusCode = StatusCodes.Status500InternalServerError
            };
        }
    }
}

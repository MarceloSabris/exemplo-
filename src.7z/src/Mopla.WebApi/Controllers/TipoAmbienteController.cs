﻿using Microsoft.AspNetCore.Mvc;
using Mopla.Application.Messages.TiposAmbientes;
using Mopla.Application.Services.TiposAmbientes;
using System;
using System.Threading.Tasks;

namespace Mopla.WebApi.Controllers
{
    public class TipoAmbienteController : Controller
    {
        private readonly ITipoAmbienteService _service;
        public TipoAmbienteController(ITipoAmbienteService service)
        {
            _service = service ?? throw new ArgumentNullException(nameof(service));
        }

        [HttpPost, HttpPut]
        [Route("tipos-ambientes")]
        public async Task<ActionResult> SalvarTiposAmbientesAsync([FromBody]SalvarTiposAmbientesRequest request)
        {
            var result = await _service.SalvarAsync(request);
            return this.GetHttpResponse(result);
        }
    }
}
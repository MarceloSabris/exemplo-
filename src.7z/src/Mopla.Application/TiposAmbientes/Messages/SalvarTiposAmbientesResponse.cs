﻿using Enterprise.Infrastructure.Services.Messages;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Mopla.Application.TiposAmbientes.Messages
{
    [DataContract(Namespace = "http://corporativo.api-cnova.com.br/moveis-planejados/v1/tipos-ambientes")]
    public class SalvarTiposAmbientesResponse : BaseResponse
    {
        [DataMember]
        public IList<string> Tipos { get; set; } = new List<string>();
    }
}
﻿using Enterprise.Infrastructure.Services.Messages;
using Mopla.Application.TiposAmbientes.Dtos;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Mopla.Application.Messages.TiposAmbientes
{
    [DataContract(Namespace = "http://corporativo.api-cnova.com.br/moveis-planejados/v1/tipos-ambientes")]
    public class SalvarTiposAmbientesRequest : BaseRequest
    {
        [DataMember]
        public IList<TipoAmbienteDto> Tipos { get; set; } = new List<TipoAmbienteDto>();
    }
}
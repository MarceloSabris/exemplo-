﻿using Mopla.Application.Messages.TiposAmbientes;
using Mopla.Application.TiposAmbientes.Messages;
using System.Threading.Tasks;

namespace Mopla.Application.Services.TiposAmbientes
{
    public interface ITipoAmbienteService
    {
        Task<SalvarTiposAmbientesResponse> SalvarAsync(SalvarTiposAmbientesRequest request);
    }
}
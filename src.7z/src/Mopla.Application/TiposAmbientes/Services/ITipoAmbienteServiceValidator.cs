﻿using Mopla.Application.Messages.TiposAmbientes;
using Mopla.Application.TiposAmbientes.Messages;
using System.Threading.Tasks;

namespace Mopla.Application.TiposAmbientes.Services
{
    public interface ITipoAmbienteServiceValidator
    {
        Task<SalvarTiposAmbientesResponse> ValidateAsync(SalvarTiposAmbientesRequest request);
    }
}
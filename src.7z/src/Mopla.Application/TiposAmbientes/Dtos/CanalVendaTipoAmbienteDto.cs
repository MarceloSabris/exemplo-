﻿using System.Runtime.Serialization;

namespace Mopla.Application.TiposAmbientes.Dtos
{
    [DataContract(Namespace = "http://corporativo.api-cnova.com.br/moveis-planejados/v1/tipos-ambientes")]
    public class CanalVendaTipoAmbienteDto
    {
        [DataMember]
        public string IdCanal { get; set; }
        [DataMember]
        public int IdUnidadeNegocio { get; set; }
        [DataMember]
        public short Ordem { get; set; }
    }
}
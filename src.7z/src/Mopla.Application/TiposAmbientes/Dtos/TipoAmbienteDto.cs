﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Mopla.Application.TiposAmbientes.Dtos
{
    [DataContract(Namespace = "http://corporativo.api-cnova.com.br/moveis-planejados/v1/tipos-ambientes")]
    public class TipoAmbienteDto
    {
        [DataMember]
        public string Id { get; set; }
        [DataMember]
        public string Nome { get; set; }
        [DataMember]
        public bool Ativo { get; set; }
        [DataMember]
        public IList<CanalVendaTipoAmbienteDto> Canais { get; set; } = new List<CanalVendaTipoAmbienteDto>();
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Mopla.Application.Messages.TiposAmbientes;
using Mopla.Application.TiposAmbientes.Messages;
using Mopla.Application.TiposAmbientes.Services;
using Mopla.Domain.Shared.CodeMessages.Models;
using Mopla.Domain.Shared.CodeMessages.Repositories;
using static Mopla.Application.Impl.Utils.ResponseUtil;

namespace Mopla.Application.Impl.TiposAmbientes.Services
{
    public class TipoAmbienteServiceValidator : ITipoAmbienteServiceValidator
    {
        private readonly ICodeMessageRepository _repository;
        public TipoAmbienteServiceValidator(ICodeMessageRepository repository)
        {
            _repository = repository ?? throw new ArgumentNullException(nameof(repository));
        }

        public async Task<SalvarTiposAmbientesResponse> ValidateAsync(SalvarTiposAmbientesRequest request)
        {
            var response = new SalvarTiposAmbientesResponse();

            if (request == null)
                return GetRequestIsNullResponse<SalvarTiposAmbientesResponse>();

            if (request.Tipos == null || !request.Tipos.Any())
            {
                var codeMessage = await _repository.ObterAsync(CodeMessage.PeloMenosUmTipoAmbienteDeveSerInformado);
                return GetInvalidRequestResponse<SalvarTiposAmbientesResponse>(codeMessage);
            }

            var codeMessages = new List<CodeMessage>();
            foreach (var tipo in request.Tipos)
            {
                if (string.IsNullOrWhiteSpace(tipo.Nome))
                {
                    var codeMessage = await _repository.ObterAsync(CodeMessage.AtributoObrigatorio);
                    codeMessage.AddValue(nameof(tipo.Nome));
                    codeMessages.Add(codeMessage);
                }

                if (tipo.Canais != null && tipo.Canais.Any())
                {
                    foreach (var canal in tipo.Canais)
                    {
                        if (string.IsNullOrWhiteSpace(canal.IdCanal))
                        {
                            var codeMessage = await _repository.ObterAsync(CodeMessage.AtributoObrigatorio);
                            codeMessage.AddValue(nameof(canal.IdCanal));
                            codeMessages.Add(codeMessage);
                        }

                        if (canal.IdUnidadeNegocio == default(int))
                        {
                            var codeMessage = await _repository.ObterAsync(CodeMessage.AtributoDeveSerMaiorQueZero);
                            codeMessage.AddValue(nameof(canal.IdUnidadeNegocio));
                            codeMessages.Add(codeMessage);
                        }
                    }
                }
            }

            if (codeMessages.Any())
                return GetInvalidRequestResponse<SalvarTiposAmbientesResponse>(codeMessages);

            return response;
        }
    }
}

﻿using Mopla.Application.Impl.TiposAmbientes.Mappers;
using Mopla.Application.Messages.TiposAmbientes;
using Mopla.Application.Services.TiposAmbientes;
using Mopla.Application.TiposAmbientes.Messages;
using Mopla.Application.TiposAmbientes.Services;
using Mopla.Domain.TiposAmbientes.Repositories;
using System;
using System.Linq;
using System.Threading.Tasks;
using static Mopla.Application.Impl.Utils.ResponseUtil;

namespace Mopla.Application.Impl.TiposAmbientes.Services
{
    public class TipoAmbienteService : ITipoAmbienteService
    {
        private readonly ITipoAmbienteServiceValidator _validator;
        private readonly ITipoAmbienteRepository _repository;
        public TipoAmbienteService(ITipoAmbienteServiceValidator validator, ITipoAmbienteRepository repository)
        {
            _validator = validator ?? throw new ArgumentNullException(nameof(validator));
            _repository = repository ?? throw new ArgumentNullException(nameof(repository));
        }
        public async Task<SalvarTiposAmbientesResponse> SalvarAsync(SalvarTiposAmbientesRequest request)
        {
            var response = new SalvarTiposAmbientesResponse();
            try
            {
                response = await _validator.ValidateAsync(request);
                if (!response.Valido) return response;

                var tiposAmbiente = request.Tipos.Map();
                await _repository.SalvarAsync(tiposAmbiente);

                response.Tipos = tiposAmbiente.Select(tipo => tipo.Id.ToString()).ToList();
            }
            catch (Exception ex)
            {
                return GetResponseError<SalvarTiposAmbientesResponse>(ex);
            }
            return response;
        }
    }
}
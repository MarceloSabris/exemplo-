﻿using Mopla.Application.TiposAmbientes.Dtos;
using Mopla.Domain.TiposAmbientes.Models;
using System;
using System.Collections.Generic;

namespace Mopla.Application.Impl.TiposAmbientes.Mappers
{
    public static class TipoAmbienteMapper
    {
        #region Canais de venda

        public static CanalVendaTipoAmbiente Map(this CanalVendaTipoAmbienteDto dto)
        {
            return CanalVendaTipoAmbiente.Criar(dto.IdCanal, dto.IdUnidadeNegocio, dto.Ordem);
        }

        public static CanalVendaTipoAmbienteDto Map(this CanalVendaTipoAmbiente entity)
        {
            return new CanalVendaTipoAmbienteDto
            {
                IdCanal = entity.IdCanal,
                IdUnidadeNegocio = entity.IdUnidadeNegocio,
                Ordem = entity.Ordem
            };
        }

        public static IList<CanalVendaTipoAmbiente> Map(this IList<CanalVendaTipoAmbienteDto> dtos)
        {
            var canais = new List<CanalVendaTipoAmbiente>();
            if (dtos != null)
            {
                foreach (var dto in dtos)
                {
                    var canal = CanalVendaTipoAmbiente.Criar(dto.IdCanal, dto.IdUnidadeNegocio, dto.Ordem);
                    canais.Add(canal);
                }
            }
            return canais;
        }

        public static IList<CanalVendaTipoAmbienteDto> Map(this IList<CanalVendaTipoAmbiente> entities)
        {
            var dtos = new List<CanalVendaTipoAmbienteDto>();
            if (entities != null)
            {
                foreach (var entity in entities)
                {
                    var dto = new CanalVendaTipoAmbienteDto
                    {
                        IdCanal = entity.IdCanal,
                        IdUnidadeNegocio = entity.IdUnidadeNegocio,
                        Ordem = entity.Ordem
                    };
                }
            }
            return dtos;
        }

        #endregion

        #region Tipos de ambiente

        public static TipoAmbiente Map(this TipoAmbienteDto dto)
        {
            var canais = dto.Canais.Map();
            return TipoAmbiente.Criar(Guid.Parse(dto.Id), dto.Nome, dto.Ativo, canais);
        }

        public static IList<TipoAmbiente> Map(this IList<TipoAmbienteDto> dtos)
        {
            var tiposAmbientes = new List<TipoAmbiente>();
            if (dtos != null)
            {
                foreach (var dto in dtos)
                {
                    var tipoAmbiente = TipoAmbiente.Criar(dto.Id, dto.Nome, dto.Ativo, dto.Canais.Map());
                    tiposAmbientes.Add(tipoAmbiente);
                }
            }
            return tiposAmbientes;
        }

        #endregion
    }
}
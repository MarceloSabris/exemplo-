﻿using Enterprise.Infrastructure.Collections;
using Enterprise.Infrastructure.MongoDB;
using Mopla.Application.Impl.TiposAmbientes.Services;
using Mopla.Application.Services.TiposAmbientes;
using Mopla.Application.TiposAmbientes.Services;
using Mopla.Domain.Shared.CodeMessages.Repositories;
using Mopla.Domain.TiposAmbientes.Repositories;
using Mopla.Infrastructure.MongoDb.Common;
using Mopla.Infrastructure.MongoDb.Shared.CodeMessages.Repositories;
using Mopla.Infrastructure.MongoDb.TiposAmbientes.Repositories;
using System;
using ContainerFactory = Enterprise.Infrastructure.DI.Factory;

namespace Mopla.Infrastructure.DI
{
    public class Bootstrap
    {
        private readonly ParsableNameValueCollection _appSettings;
        private readonly ContainerFactory _factory = ContainerFactory.Instance;

        public Bootstrap(ParsableNameValueCollection appSettings, IServiceProvider serviceProvider)
        {
            if ((_appSettings = appSettings) == null)
                throw new ArgumentNullException("appSettings");

            _factory.Initialize(serviceProvider);
        }

        public void Initialize()
        {
            _factory.Registrar<ParsableNameValueCollection>(true, _appSettings);
            RegisterInfrastructure();
            RegisterRepositories();
            RegisterValidators();
            RegisterServices();
        }

        private void RegisterInfrastructure()
        {
            _factory.Registrar<SimpleMongoClient>(true, SimpleMongoClient.CreateFromConfig("mongoclient-", _appSettings));
            _factory.Registrar<IDataBaseFacade>(true, new DataBaseFacade(_factory.Criar<SimpleMongoClient>()));
        }
        private void RegisterRepositories()
        {
            _factory.Registrar<ICodeMessageRepository>(true, new CodeMessageRepository(_factory.Criar<IDataBaseFacade>(), CollectionsNames.CodeMessagesCollectionName));
            _factory.Registrar<ITipoAmbienteRepository>(true, new TipoAmbienteMongoRepository(_factory.Criar<IDataBaseFacade>(), CollectionsNames.TiposAmbientesCollectionName));
        }
        private void RegisterValidators()
        {
            _factory.Registrar<ITipoAmbienteServiceValidator>(true, new TipoAmbienteServiceValidator(_factory.Criar<ICodeMessageRepository>()));
        }
        private void RegisterServices()
        {
            _factory.Registrar<ITipoAmbienteService>(true, new TipoAmbienteService(_factory.Criar<ITipoAmbienteServiceValidator>(), _factory.Criar<ITipoAmbienteRepository>()));
        }
    }
}